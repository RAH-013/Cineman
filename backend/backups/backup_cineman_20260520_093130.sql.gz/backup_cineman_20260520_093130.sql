/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.14-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: mysql    Database: cineman
-- ------------------------------------------------------
-- Server version	8.4.8

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `logs`
--

DROP TABLE IF EXISTS `logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `logs` (
  `id` char(36) COLLATE utf8mb4_spanish_ci NOT NULL DEFAULT (uuid()),
  `request_id` char(36) COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `token_jti` varchar(255) COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `user_id` char(36) COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `user_role` enum('user','manager','admin') COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `action` varchar(100) COLLATE utf8mb4_spanish_ci NOT NULL,
  `severity` enum('info','warning','critical') COLLATE utf8mb4_spanish_ci NOT NULL DEFAULT 'info',
  `ip_address` varchar(45) COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_spanish_ci,
  `endpoint` varchar(255) COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `method` varchar(10) COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `status_code` int DEFAULT NULL,
  `message` text COLLATE utf8mb4_spanish_ci NOT NULL,
  `context` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `fk_user_logs_user` (`user_id`),
  KEY `idx_logs_action` (`action`),
  KEY `idx_logs_user_role` (`user_role`),
  KEY `idx_logs_created_at` (`created_at`),
  CONSTRAINT `fk_user_logs_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `logs`
--

LOCK TABLES `logs` WRITE;
/*!40000 ALTER TABLE `logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `movies`
--

DROP TABLE IF EXISTS `movies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `movies` (
  `id` char(36) COLLATE utf8mb4_spanish_ci NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_spanish_ci NOT NULL,
  `director` varchar(255) COLLATE utf8mb4_spanish_ci NOT NULL,
  `synopsis` text COLLATE utf8mb4_spanish_ci NOT NULL,
  `genres` set('accion','aventura','animada','comedia','crimen','drama','fantasia','horror','romance','sci_fi','thriller','misterio','videojuego','terror','noir') COLLATE utf8mb4_spanish_ci NOT NULL,
  `duration_minutes` int NOT NULL,
  `classification` enum('AA','A','B','B15','C','D') COLLATE utf8mb4_spanish_ci NOT NULL,
  `release_date` date NOT NULL,
  `poster_url` text COLLATE utf8mb4_spanish_ci,
  `trailer_url` text COLLATE utf8mb4_spanish_ci,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `movies`
--

LOCK TABLES `movies` WRITE;
/*!40000 ALTER TABLE `movies` DISABLE KEYS */;
INSERT INTO `movies` VALUES
('292aab1b-4c9b-ab7c-76db-41ea60a2ab7f','Jackass 5','Jeff Tremaine','El equipo de Jackass regresa con nuevas y peligrosas locuras, desafíos extremos y bromas aún más absurdas que ponen a prueba los límites del dolor y la comedia.','accion,comedia',95,'C','2026-11-27','https://image.tmdb.org/t/p/w600_and_h900_face/zAMl7Yg265JSSL10hvzmMIB0a4V.jpg','rJV9CqGZajg',1,'2026-05-19 19:19:39'),
('342f5203-4db7-b386-c6cd-0075577ce24c','BACKROOMS','Kane Parsons','Un joven queda atrapado en un inquietante laberinto de habitaciones infinitas conocido como los Backrooms.','sci_fi,misterio,terror',100,'B15','2025-12-28','https://image.tmdb.org/t/p/w1280/w8nrM9hCTxoeX96HmTQpC0HbkMY.jpg','j6xBUJSm_S8',1,'2026-05-19 18:59:52'),
('38bada03-4491-8889-90a3-a2d4c6da0a64','Avatar: Fire and Ash','James Cameron','Jake Sully y Neytiri enfrentan una nueva amenaza en Pandora mientras surgen conflictos entre diferentes clanes Na’vi.','accion,aventura,sci_fi',192,'B','2025-12-19','https://media.themoviedb.org/t/p/w600_and_h900_face/vHtH4xdcTbaCVftGwaeGFHfOB3p.jpg','nb_fFj_0rq8',1,'2026-05-19 18:59:52'),
('578ffc7b-4566-a7b1-0bbb-5cf6b0296194','Dune: Parte 3','Denis Villeneuve','Paul Atreides enfrenta las consecuencias de su ascenso mientras el imperio entra en una nueva etapa de conflicto y fanatismo.','aventura,drama,sci_fi',170,'B15','2026-12-18','https://tse4.mm.bing.net/th/id/OIP.rL2ypfNIwegxbQoRJA9sKgHaJ4?cb=thfc1falcon&rs=1&pid=ImgDetMain&o=7&rm=3','3_9vCamtuPY',1,'2026-05-19 18:59:52'),
('7cb1d3b5-49c9-aaf9-88d2-66913de7f85d','Wildwood','Travis Knight','Prue McKeel y su amigo Curtis se adentran en un bosque mágico y peligroso para rescatar al hermano menor de Prue después de que es secuestrado por cuervos.','aventura,animada,fantasia',110,'A','2026-10-23','https://image.tmdb.org/t/p/original/dSjy8wUsHamYlkVdda2Spj5axhl.jpg','POneS8h1jyU',1,'2026-05-19 18:59:52'),
('844aea03-480a-a77a-edff-f4f899e4d494','Spider-Man: Brand New Day','Destin Daniel Cretton','Peter Parker intenta reconstruir su vida mientras enfrenta nuevas amenazas tras los eventos que cambiaron su identidad para siempre.','accion,aventura,sci_fi',140,'B','2026-07-31','https://image.tmdb.org/t/p/w1280/4eb4y74sZlJ60LFA1LqZvRuNU1o.jpg','1UNIRI7tUrg',1,'2026-05-19 18:59:52'),
('a46d5338-43f4-a2ee-3ce0-0ca9254161b4','Resident Evil','Zach Cregger','Un nuevo brote biológico desata el caos mientras un grupo de sobrevivientes intenta escapar de criaturas mutadas y conspiraciones corporativas.','accion,sci_fi,terror',115,'C','2026-09-18','https://cdn.cinematerial.com/p/297x/bqwgcqfg/resident-evil-poster-md.jpg?v=1756641558','SJPu1spHqfk',1,'2026-05-19 18:59:52'),
('acb5f9cc-4bac-8910-5603-66ba079932d1','Spider-Noir','Harry Bradbeer','Un envejecido investigador privado en una Nueva York alternativa de los años 30 enfrenta su pasado como el único superhéroe de la ciudad.','accion,crimen,sci_fi,noir',50,'B15','2026-01-01','https://image.tmdb.org/t/p/w1280/cRAzL6mmdM6Q6UuQgc335UMgcfd.jpg','HDXosdQkwcw',1,'2026-05-19 18:59:52'),
('c0e7e1ac-4c7c-a533-af40-622040421ea7','Supergirl','Craig Gillespie','Kara Zor-El emprende un viaje por el universo mientras intenta encontrar su lugar como heroína en un mundo lleno de amenazas.','accion,aventura,fantasia,sci_fi',135,'B','2026-06-26','https://tse2.mm.bing.net/th/id/OIP.9DyrxhAsCsH08oj8bQFhUQHaJX?cb=thfc1falcon&rs=1&pid=ImgDetMain&o=7&rm=3','s1-pfiVMKAs',1,'2026-05-19 18:59:52'),
('cabd82c8-411b-8b95-62cf-1d253be92bc6','Scary Movie 6','Marlon Wayans','Una nueva ola de parodias lleva a un grupo de personajes a enfrentarse a situaciones absurdas inspiradas en películas de terror modernas.','comedia,terror',98,'C','2026-06-12','https://image.tmdb.org/t/p/w1280/iYQnvP1DrgSaoSbYPuNCPr3TRqk.jpg','Zszr3BTpqPE',1,'2026-05-19 18:59:52'),
('d678c0d8-4e34-a8d3-8927-082e63b87c95','Street Fighter','Kitao Sakurai','Los luchadores más poderosos del mundo se enfrentan en un torneo que decidirá el destino de la humanidad.','accion,aventura,videojuego',125,'B15','2026-03-19','https://image.tmdb.org/t/p/w600_and_h900_face/76r5jb2FnsYjQRWs8bn7r9TVWGS.jpg','Xt4X4FvXk2A',1,'2026-05-19 18:59:52');
/*!40000 ALTER TABLE `movies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `showtimes`
--

DROP TABLE IF EXISTS `showtimes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `showtimes` (
  `id` char(36) COLLATE utf8mb4_spanish_ci NOT NULL,
  `movie_id` char(36) COLLATE utf8mb4_spanish_ci NOT NULL,
  `room` enum('1','2','3','4','5') COLLATE utf8mb4_spanish_ci NOT NULL,
  `start_time` datetime NOT NULL,
  `language` enum('SUB','ESP') COLLATE utf8mb4_spanish_ci NOT NULL,
  `format` enum('2D','3D','IMAX') COLLATE utf8mb4_spanish_ci NOT NULL DEFAULT '2D',
  `price` decimal(10,2) NOT NULL,
  `available_seats` int NOT NULL DEFAULT '50',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_showtimes_movie` (`movie_id`),
  KEY `idx_showtimes_start_time` (`start_time`),
  CONSTRAINT `fk_showtimes_movie` FOREIGN KEY (`movie_id`) REFERENCES `movies` (`id`) ON DELETE CASCADE,
  CONSTRAINT `showtimes_chk_1` CHECK ((`price` >= 0)),
  CONSTRAINT `showtimes_chk_2` CHECK ((`available_seats` between 0 and 50))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `showtimes`
--

LOCK TABLES `showtimes` WRITE;
/*!40000 ALTER TABLE `showtimes` DISABLE KEYS */;
/*!40000 ALTER TABLE `showtimes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tickets`
--

DROP TABLE IF EXISTS `tickets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tickets` (
  `id` char(36) COLLATE utf8mb4_spanish_ci NOT NULL,
  `user_id` char(36) COLLATE utf8mb4_spanish_ci NOT NULL,
  `showtime_id` char(36) COLLATE utf8mb4_spanish_ci NOT NULL,
  `seat_row` enum('A','B','C','D','E') COLLATE utf8mb4_spanish_ci NOT NULL,
  `seat_number` int NOT NULL,
  `total_price` decimal(10,2) NOT NULL,
  `status` enum('reserved','paid') COLLATE utf8mb4_spanish_ci NOT NULL DEFAULT 'reserved',
  `expires_at` datetime NOT NULL,
  `purchased_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_ticket_seat` (`showtime_id`,`seat_row`,`seat_number`),
  KEY `idx_tickets_user` (`user_id`),
  KEY `idx_tickets_showtime` (`showtime_id`),
  KEY `idx_tickets_status` (`status`),
  KEY `idx_tickets_expires` (`expires_at`),
  CONSTRAINT `fk_tickets_showtime` FOREIGN KEY (`showtime_id`) REFERENCES `showtimes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_tickets_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `tickets_chk_1` CHECK ((`seat_number` between 1 and 10))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tickets`
--

LOCK TABLES `tickets` WRITE;
/*!40000 ALTER TABLE `tickets` DISABLE KEYS */;
/*!40000 ALTER TABLE `tickets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_profiles`
--

DROP TABLE IF EXISTS `user_profiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_profiles` (
  `user_id` char(36) COLLATE utf8mb4_spanish_ci NOT NULL,
  `name` varchar(30) COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `lastname` varchar(100) COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `phone` varchar(20) COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`),
  CONSTRAINT `fk_user_profiles_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_profiles`
--

LOCK TABLES `user_profiles` WRITE;
/*!40000 ALTER TABLE `user_profiles` DISABLE KEYS */;
INSERT INTO `user_profiles` VALUES
('ce529c61-5460-11f1-b225-0242ac170002',NULL,NULL,NULL,'2026-05-20 15:30:18'),
('ce52a049-5460-11f1-b225-0242ac170002',NULL,NULL,NULL,'2026-05-20 15:30:18');
/*!40000 ALTER TABLE `user_profiles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` char(36) COLLATE utf8mb4_spanish_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_spanish_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_spanish_ci NOT NULL,
  `role` enum('admin','manager','user') COLLATE utf8mb4_spanish_ci NOT NULL DEFAULT 'user',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
('ce529c61-5460-11f1-b225-0242ac170002','admin@cineman.com','$2y$12$ykGsKbSnO4I9NCLlj1T2Oueci8knJGCfzLsjWFEvcwcVQQKPozGkm','admin','2026-05-20 15:30:18'),
('ce52a049-5460-11f1-b225-0242ac170002','manager@cineman.com','$2y$12$fCPsfmUJ8f0.0Sp0P2NfneItpCo91XMl0a9Hg1ggiOeZR/gSzBlae','manager','2026-05-20 15:30:18');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-05-20  9:31:30
